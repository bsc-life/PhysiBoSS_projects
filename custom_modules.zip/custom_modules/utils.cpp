/*

Small util scripts

*/

#include "./utils.h"

